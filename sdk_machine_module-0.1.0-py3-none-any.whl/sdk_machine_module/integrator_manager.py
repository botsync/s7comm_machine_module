from sdk_machine_module.redis_driver import RedisDriver
import json
from sdk_machine_module.logger_setup import LoggerSetup
import yaml
import xmlrpc.server
import xmlrpc.server,socketserver
from  xmlrpc.server import SimpleXMLRPCServer, SimpleXMLRPCRequestHandler
#wrap the function in a try except block
from functools import wraps
import traceback

class IntegratorManager:

    class SilenceableXMLRPCRequestHandler(SimpleXMLRPCRequestHandler):

        def log_message(self, format, *args):
            if 0:
                SimpleXMLRPCRequestHandler.log_message(self, format, *args)

    class RPCThreading(socketserver.ThreadingMixIn, xmlrpc.server.SimpleXMLRPCServer):

        daemon_threads = True

    __redis_driver = None
    ___function_map = {}
    __config_map = {}
    __module_name = ""
    ___monitors = {}
    ___options_mapping = {}
    __config_file_path = ""
    __port = 1029
    __server = None

    def __exception_handler(func):

        @wraps(func)
        def wrapper(self, *args, **kwargs):
            try:
                return func(self, *args, **kwargs)
            except Exception as e:
                self.__logger.error(f"{func.__name__} === {e}")
                raise e
        return wrapper

    # @staticmethod
    # @yaml_loader
    @__exception_handler
    def get_machine_details(self, function_type=None, function_name=None):
        # self.__logger.info("Getting Machine Details")
        details = self.__config_map
        self.__logger.debug(details)
        self.__logger.debug(function_type)
        self.__logger.debug(function_type)
        self.__logger.debug(function_type)
        self.__logger.debug(details.get(function_type))
        if function_type:
            if function_name:
                return details.get(function_type).get(function_name)
            else:
                return details.get(function_type)
        return details or {}



    @__exception_handler
    def get_options(self, machine_uid: str, event_name: str, event_type: str, context: str, context_params={}):
        details = self.___options_mapping
        # self.__logger.info(details)
        if event_name in details.keys():
            options_map = details.get(event_name)
            if context in options_map.keys():
                resp = options_map.get(context)
                if callable(resp):
                    return resp(machine_uid, **context_params)
                self.__logger.info(resp)
                return resp
        return []

    def add_machine_config(self, uid: str, machine_name: str, config: dict):
        data = None
        config['name'] = machine_name
        with open(self.__config_file_path, 'r+') as file:
            data = json.load(file)
        if data != None:
            data[uid] = config
        with open(self.__config_file_path, 'w+') as out:
            json.dump(data, out)
        return True

    @__exception_handler
    def get_machine_config(self, uid:str):
        with open(self.__config_file_path, 'r') as file:
            return json.load(file).get(uid, {})

    @__exception_handler
    def add_machine(self, uid: str, machine_name: str, config: str):
        #Add Machine
        config = json.loads(config)
        self.add_machine_config(uid, machine_name, config)
        return [True, "Machine Added Successfully"]

    def delete_machine_config(self, uid: str):
        with open('config.json', 'r+') as file:
            data = json.load(file)
        if data != None:
            value = data.get(uid)
            if value:
                del data[uid]
                with open('config.json', 'w+') as out:
                    json.dump(data, out)
            return value
        return None


    @__exception_handler
    def delete_machine(self, uid):
        self.delete_machine_config(uid)
        return [True, "Machine Deleted Successfully"]

    def call_function(self, func):
        def wrapper(*args, **kwargs):
            machine_id = kwargs.pop("uid")
            configs = self.get_machine_config(machine_id)
            func_args = kwargs.pop("kargs")
            kargs = {}
            # kargs['configs'] = configs
            kargs['uid'] = machine_id
            kargs['kargs'] = func_args
            kargs['machine_configs'] = configs
            return func(**kargs)
        return wrapper

    def log_statement(self, statement: str, level="INFO"):
        if level == "INFO":
            self.__logger.info(statement)
        elif level == "DEBUG":
            self.__logger.debug(statement)
        elif level == "ERROR":
            self.__logger.error(statement)
        elif level == "CRITICAL":
            self.__logger.critical(statement)
        elif level == "WARNING":
            self.__logger.warning(statement)

    def __init__(self,
                 module_name,
                 module_setup_file_path,
                 machine_config_file_path,
                 port=1029,
                 redis_hostname='0.0.0.0',
                 redis_port='6387',
                 logger_identifier='random',
                 logger_file_path="./logger.log",
                 log_level="INFO",
                 run_call_function_rate=0.001
                 ):

        ''''
            machine_setup_file_path: machine_detail.yml
            machine_config_file_path: machine_config.json
        '''
        self.__module_name = module_name
        self.__port = port
        self.__config_file_path = machine_config_file_path
        self.__logger = LoggerSetup(
            logger_name=logger_identifier,
            file_path=logger_file_path,
            log_level=log_level
        ).get_logger()
        self.__redis_driver = RedisDriver(
            hostname=redis_hostname,
            port=redis_port,
            logger=self.__logger,
            subscription_rate=run_call_function_rate
            )

        self.add_setup_file(module_setup_file_path)
        self.__subscribe_to_call_function()
        self.__subscribe_to_monitor_function()
        self.__create_server()
        self.__register_functions()

    def __create_server(self):
        self.__server = IntegratorManager.RPCThreading(("0.0.0.0", self.__port), allow_none=True)

    @__exception_handler
    def ping(self, uid):
        if not uid:
            return False
        else:
            config = self.get_machine_config(uid)
            if config and type(config) == dict and config.get('name'):
                return True
            else:
                return False

    def register_xml_function(self, func):
        if not callable(func):
            raise Exception(f"Function is not callable: Error registering")
        self.__server.register_function(func)


    def __register_functions(self):
        self.__server.register_function(self.add_machine)
        self.__server.register_function(self.get_machine_config)
        self.__server.register_function(self.get_machine_details)
        self.__server.register_function(self.get_options)
        self.__server.register_function(self.ping)
        self.__server.register_function(self.delete_machine)

    def publish_to_some_other_topic(self, topic: str, message: str):
        self.__redis_driver.publish(topic, message)

    def get_all_machine(self):
        with open(self.__config_file_path, 'r') as file:
            return json.load(file)

    def start(self):
        '''
            Starts the server indefinitely

            Should be called after all the functions are registered
        '''
        print(f"Starting server @ {self.__port}")
        if self.__server:
            self.__server.serve_forever()

    def add_setup_file(self, setup_path):
        with open(setup_path, "r") as f:
            self.__config_map = yaml.safe_load(f)
            self.__logger.info(f"====Config Loaded ==== {self.__config_map}")

    def publish_to_dashboard(self, message: str):
        # redis_driver = RedisDriver()
        self.__redis_driver.publish_to_dashboard(message)

    def send_call_function_response(self, event_name, machine_id, sync_context, response):
        self.__redis_driver.publish("call_function_response", json.dumps({
            "event_name": event_name,
            "event_data": response,
            "machine_id": machine_id,
            "event_type": "call",
            "sync_id": sync_context.get("sync_id"),
            "node_id": sync_context.get("node_id"),
            "flow_id": sync_context.get("flow_id")
        }))

    def send_event(self, event_name, machine_id, response):
        """
            Send event to workflow Manager

            event_name: str
            machine_id: str
            response: dict
        """
        self.__redis_driver.publish('event_queue', json.dumps({
                 'event_name': event_name,
                 'event_data': response,
                 'machine_id': machine_id,
                 'event_type': "monitor",
            }))

    def publish_an_error(self, machine_id, error_code, error_message):
        pass

    # def send_error(self, machine_id, error_code, error_message, error_name, error_args={}):
    #     self.__redis_driver.publish("error_queue", json.dumps({
    #         'error_name': error_name,
    #         'error_code': error_code,
    #         'error_args': error_args,
    #         'error_message': error_message,
    #         "machine_id": machine_id
    #     }))

    def send_error(self, error_message, event_name, machine_id, event_args, event_type, node_id="", flow_id="", sync_id=""):
        self.__redis_driver.publish("error_queue", json.dumps({
            'error_message': error_message,
            'event_name': event_name,
            'machine_id': machine_id,
            'event_args': event_args,
            "event_type": event_type,
            "node_id": node_id,
            "flow_id": flow_id,
            "sync_id": sync_id,
            "machine_module_name": self.__module_name
        }))

    def __executer(self, function_name, kargs, machine_id, sync_context):
        self.__logger.debug(self.___function_map)
        if function_name in self.___function_map.keys():
            func = self.___function_map.get(function_name)
            try:
                kargs = json.loads(kargs)
            except Exception as e:
                self.__logger.info(f"Error in parsing kargs: {e}")
                self.__redis_driver
            response = func(uid=machine_id, kargs=kargs)
            event_name = self.__config_map['call_functions'][function_name]["event_response"]
            self.__logger.debug(f"Sending Response ==== {function_name} ==== {response}")
            self.send_call_function_response(event_name, machine_id, sync_context, response)

    def __executor_monitor(self, monitor_name, kargs, machine_id, ):
        self.__logger.debug(self.___monitors)
        if monitor_name in self.___monitors.keys():
            monitor_func = self.___monitors.get(monitor_name)
            self.__logger.debug(f"Monitor Function: {monitor_name}")
            if monitor_func:
                monitor_func(app=self, uid=machine_id, kargs=kargs)
            # else:
            #     monitor.stop(self, machine_id, func_args=kargs, sync_context=sync_context)
            # event_name = self.__config_map['monitor_functions'][function_name]["event_response"]
            # self.send_monitor_function_response(event_name, machine_id, response)

    def __subscribe_to_call_function(self, ):
        self.__redis_driver.thread_subscribe(f"{self.__module_name}_call_functions", self.__call_function_response)

    def __subscribe_to_monitor_function(self):
         self.__redis_driver.thread_subscribe(f"{self.__module_name}_monitor_functions", self.__monitor_function_response)

    @__exception_handler
    def register_call_function(self, function_name, function, options={}, response_options={}):
        """
            function: callable function
            Required params:
                machine_id: str
                func_args: dict
        """
        if not callable(function):
            raise Exception("Function should be callable")
        self.__logger.debug(f"Registering Function: {function_name}")
        self.___function_map[function_name] = function
        self.___options_mapping[function_name] = options
        event_response = self.__config_map['call_functions'][function_name]["event_response"]
        self.___options_mapping[event_response] = response_options

    @__exception_handler
    def register_monitor_function(self, monitor_name, monitor_func, options={}, response_options={}):
        '''
            monitor_func:
                Required params:
                    app: IntegratorManager
                    machine_id: str
                    func_args: dict
                    sync_context: dict
        '''
        if callable(monitor_func):
            self.___monitors[monitor_name] = monitor_func
            self.___options_mapping[monitor_name] = options
            event_response = self.__config_map['monitor_functions'][monitor_name]["event_response"]
            self.___options_mapping[event_response] = response_options
        else:
            raise Exception("Monitor Function should be callable")


    def __monitor_function_response(self, message):
        self.__logger.debug(message)
        kargs = message.get("args")
        function_name = message.get("function_name")
        uid = message.get("machine_id")
        try:
            # print("RECEIVED")
            # message = json.loads(message)

            # sync_id = message.get("sync_id")
            # node_id = message.get("node_id")
            # flow_id  = message.get("flow_id")
            # time_now = message.get("time")
            # start = message.get("start", True)
            # now = datetime.datetime.now().timestamp()
            # time_released = datetime.datetime.strptime(time_now, "%Y-%m-%d %H:%M:%S")
            # logger.error(f"Time now: {now - time_now}")
            # sync_context = {
            #     "sync_id": sync_id,
            #     "node_id": node_id,
            #     "flow_id": flow_id
            # }
            self.__executor_monitor(function_name, kargs, uid)
        except Exception as e:
            self.__logger.critical(f"ERROR in parsing message: {e}")
            tb_str = ''.join(traceback.format_exception(e))
            self.send_error(
                error_message=tb_str,
                event_name=function_name,
                machine_id=uid,
                event_args=kargs,
                event_type="monitor"
            )

    def __call_function_response(self, message):
        self.__logger.debug(message)
        kargs = message.get("args")
        function_name = message.get("function_name")
        uid = message.get("machine_id")
        sync_id = message.get("sync_id")
        node_id = message.get("node_id")
        flow_id  = message.get("flow_id")
        time_now = message.get("time")
        try:
            # message = json.loads(message)

            # now = datetime.datetime.now().timestamp()
            # time_released = datetime.datetime.strptime(time_now, "%Y-%m-%d %H:%M:%S")
            # logger.error(f"Time now: {now - time_now}")
            sync_context = {
                "sync_id": sync_id,
                "node_id": node_id,
                "flow_id": flow_id
            }
            self.__executer(function_name, kargs, uid, sync_context)
        except Exception as e:
            self.__logger.critical(f"ERROR in parsing message: {e}")
            tb_str = ''.join(traceback.format_exception(None, e, e.__traceback__))
            self.send_error(
                error_message=tb_str,
                event_name=function_name,
                machine_id=uid,
                event_args=kargs,
                event_type="call",
                node_id=node_id,
                flow_id=flow_id,
                sync_id=sync_id
            )




