import logging
import os

# path = os.path.dirname(os.path.realpath(__file__))

# file_path = f"/system.log"
# if os.environ.get("ENV") == "LOCAL":
#     file_path = "./system.log"


class LoggerSetup:

    __logger = None
    __stream_handler = None



    def get_logger(self):
        if self.__logger:
            return self.__logger


    def __init__(self, logger_name, file_path, log_level : str = "ERROR"):
        self.__logger = logging.getLogger(
                name=logger_name
        )
        self.__stream_handler = logging.FileHandler(
            filename=file_path,
            mode='w'
        )
        current_level = log_level
        if current_level == "DEBUG":
            self.__logger.setLevel(logging.DEBUG)
        elif log_level == "INFO":
            self.__logger.setLevel(logging.INFO)
        elif log_level == "CRITICAL":
            self.__logger.setLevel(logging.CRITICAL)
        else:
            self.__logger.setLevel(logging.ERROR)
        self.__stream_handler.setFormatter(
            logging.Formatter(
                '%(asctime)s - %(levelname)s - %(message)s',
                datefmt='%d/%m/%Y %I:%M:%S %p'
            )
        )
        self.__logger.addHandler(self.__stream_handler)

