import threading

class Monitor:
    __func = None
    __event_thread = threading.Event()
    __sleep = 1
    __running = False
    __end_func = None
    __start_func = None

    def __init__(self, func, start_func=None, end_func=None, sleep=1):
        '''
            func: callable function to be executed in loop
            start_func: callable function to be executed before starting the monitor
            end_func: callable function to be executed after stopping the monitor
            sleep: time to sleep before executing the function again
        '''


        if callable(func):
            self.__func = func
        else:
            raise ValueError("Monitor class requires a callable function")
        self.__sleep = sleep

    def start(self, integrator_instance, machine_id,  *args, **kwargs):
        def __monitor(integrator_instance, *args, **kwargs):
            self.__event_thread.set()
            while self.__event_thread.is_set():
                self.__func(integrator_instance, machine_id,  *args, **kwargs)

        if self.__event_thread.is_set():
            self.__event_thread.clear()
        if self.__running:
            if self.__end_func:
                self.__end_func(integrator_instance, machine_id, *args, **kwargs)
        if self.__start_func:
            self.__start_func(integrator_instance, machine_id, *args, **kwargs)
        t = threading.Thread(target=__monitor, args=(integrator_instance, machine_id, *args), kwargs=kwargs)
        t.start()

    def stop(self):
        self.__event_thread.clear()
        if self.__running and self.__end_func:
            self.__end_func()
        self.__running = False
