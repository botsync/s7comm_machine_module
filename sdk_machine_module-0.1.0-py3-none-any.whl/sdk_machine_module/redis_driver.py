from re import L
import threading
from dotenv import load_dotenv
import os
import redis
from sdk_machine_module.logger_setup import LoggerSetup
import time
import json

class RedisDriver(object):
    HOSTNAME = None
    PORT = None
    _instance = None
    _server = None
    __subscription_rate = 0.001

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(RedisDriver, cls).__new__(cls)
        return cls._instance

    def __init__(self, hostname, port, logger, subscription_rate=0.001):
        self.HOSTNAME = hostname
        self.PORT = port
        self._server = redis.Redis(
                host=self.HOSTNAME,
                port=self.PORT,
                decode_responses=True
        )
        self.logger = logger
        self.logger.debug(subscription_rate)
        self.__subscription_rate = subscription_rate

    def publish_to_dashboard(self, message):
        self.publish("dashboard", message)


    # def get_server(self):
    #     if not self._server:

    #     return self.server


    def publish(self, channel: str, message: str):
        serv = self._server
        serv.publish(channel, message)

    def thread_subscribe(self, channel: str, callback):
        """
            Thread Subscriber function for redis pubsub
            Run it in thread pool or seperate thread
        """
        def background(channel, callback):
            self.logger.info(f"Subscribing to {channel}")
            try:
                self.logger.debug("Subscribing to channel")
                pubsub = self._server.pubsub(ignore_subscribe_messages=True)
                pubsub.subscribe(f'{channel}')
                while True:
                    # self.logger.debug("ADDEDD =============================================")
                    try:
                        self.logger.debug(f"Waiting for message in channel: {channel}")
                        message = pubsub.get_message(timeout=60)
                        if message and message.get('data'):
                            self.logger.debug(f"Message received: {message['data']}")
                            self.logger.debug(message['data'])
                            message = json.loads(message['data'])
                            callback(message)
                    except Exception as e:
                        self.logger.critical(f"Error in RedisDriver.thread_subscribe: {str(e)}")
                    self.logger.debug(f"Sleeping for {self.__subscription_rate} seconds")
                    time.sleep(self.__subscription_rate)
            except Exception as e:
                self.logger.error(f"====== Error from Machine Module SDK ======= Error in RedisDriver.thread_subscribe: {str(e)}")

            return

        threading.Thread(target=background, args=(channel, callback), daemon=True).start()

    @classmethod
    def close_server(self):
        if self._server:
            self._server.close()